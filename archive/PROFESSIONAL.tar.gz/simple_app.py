import streamlit as st

# Configure page settings - MUST be first Streamlit command
st.set_page_config(
    page_title="LoanScoreAI v6.0",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import io
import sqlite3
from scoring_engine import LoanScoringEngine
from database import DatabaseManager
from utils import create_excel_output, validate_csv_columns
from validators import validate_individual_data
from weights_config import render_weights_configuration

def render_bulk_upload():
    """Comprehensive bulk upload processing for large CSV files"""
    st.header("📁 Bulk Upload Processing")
    st.write("Upload CSV files with thousands of loan applications for batch scoring")
    
    # File upload section
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📤 Upload CSV File")
        uploaded_file = st.file_uploader(
            "Choose CSV file with loan applications",
            type=['csv'],
            help="Maximum file size: 200MB | Maximum records: 25,000"
        )
    
    with col2:
        st.subheader("📋 Download Template")
        # Read the template file
        try:
            with open("bulk_template_20vars.csv", "r") as f:
                template_data = f.read()
            
            st.download_button(
                label="📥 Download 20-Variable Template",
                data=template_data,
                file_name="loan_application_template_20vars.csv",
                mime="text/csv",
                help="Template with all 20 variables for comprehensive scoring"
            )
        except:
            st.warning("Template file not found")
    
    if uploaded_file is not None:
        try:
            # Load and preview data
            df = pd.read_csv(uploaded_file)
            
            st.success(f"✅ File uploaded successfully! Found {len(df)} applications")
            
            # Validation section
            st.subheader("🔍 Data Validation")
            
            # Check required columns (case-insensitive mapping)
            required_columns = [
                'Pan', 'Age', 'MonthlyIncome', 'CreditScore', 'FOIR', 'DPD_30_Plus', 
                'EnquiryCount', 'CreditVintage', 'LoanMixType', 'LoanCompletionRatio',
                'DefaultedLoans', 'CompanyType', 'EmploymentTenure', 'CompanyStability',
                'AccountVintage', 'AMB', 'BounceCount', 'GeoRisk',
                'MobileVintage', 'DigitalScore', 'UnsecuredLoanAmount',
                'OutstandingPercent', 'OurLenderExposure', 'ChannelType'
            ]
            
            missing_columns = [col for col in required_columns if col not in df.columns]
            extra_columns = [col for col in df.columns if col not in required_columns]
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if missing_columns:
                    st.error(f"❌ Missing columns: {len(missing_columns)}")
                    for col in missing_columns:
                        st.text(f"• {col}")
                else:
                    st.success("✅ All required columns present")
            
            with col2:
                if extra_columns:
                    st.warning(f"⚠️ Extra columns: {len(extra_columns)}")
                    for col in extra_columns:
                        st.text(f"• {col}")
                else:
                    st.success("✅ No extra columns")
            
            with col3:
                st.metric("Total Records", len(df))
                st.metric("Total Columns", len(df.columns))
            
            # Data preview
            st.subheader("👀 Data Preview")
            st.dataframe(df.head(10), use_container_width=True)
            
            # Processing options
            if not missing_columns:
                st.subheader("⚙️ Processing Options")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    batch_size = st.selectbox(
                        "Batch Size",
                        [100, 500, 1000, 2500, 5000],
                        index=1,
                        help="Process records in batches to manage memory"
                    )
                
                with col2:
                    include_detailed_scores = st.checkbox(
                        "Include Variable Scores",
                        value=True,
                        help="Include detailed breakdown for each variable"
                    )
                
                with col3:
                    error_handling = st.selectbox(
                        "Error Handling",
                        ["Skip invalid records", "Stop on first error"],
                        help="How to handle validation errors"
                    )
                
                # Process button
                if st.button("🚀 Process Bulk Applications", type="primary", use_container_width=True):
                    process_bulk_applications(df, batch_size, include_detailed_scores, error_handling)
            
        except Exception as e:
            st.error(f"❌ Error reading file: {str(e)}")
            st.info("Please ensure your CSV file has the correct format and encoding (UTF-8)")

def process_bulk_applications(df, batch_size, include_detailed_scores, error_handling):
    """Process bulk applications with progress tracking"""
    
    # Initialize progress tracking
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total_records = len(df)
    processed_count = 0
    successful_count = 0
    error_count = 0
    results = []
    error_log = []
    
    # Reload weights and reinitialize engine for updated thresholds
    st.session_state.scoring_engine.reload_weights()
    # Force refresh of the scoring engine to pick up threshold changes
    st.session_state.scoring_engine = LoanScoringEngine()
    
    try:
        # Process in batches
        for batch_start in range(0, total_records, batch_size):
            batch_end = min(batch_start + batch_size, total_records)
            batch_df = df.iloc[batch_start:batch_end]
            
            status_text.text(f"Processing batch {batch_start//batch_size + 1}: Records {batch_start + 1} to {batch_end}")
            
            for idx, row in batch_df.iterrows():
                try:
                    # Prepare applicant data with column mapping
                    applicant_data = {
                        # Core Credit Variables
                        'pan': str(row.get('Pan', '')).strip(),
                        'age': int(row.get('Age', 0)),
                        'monthly_income': float(row.get('MonthlyIncome', 0)),
                        'credit_score': int(row.get('CreditScore', 0)),
                        'foir': float(row.get('FOIR', 0)),
                        'dpd30plus': int(row.get('DPD_30_Plus', 0)),
                        'enquiry_count': int(row.get('EnquiryCount', 0)),
                        # Behavioral Analytics
                        'credit_vintage': int(row.get('CreditVintage', 0)),
                        'loan_mix_type': str(row.get('LoanMixType', '')),
                        'loan_completion_ratio': float(row.get('LoanCompletionRatio', 0)),
                        'defaulted_loans': int(row.get('DefaultedLoans', 0)),
                        # Employment Stability
                        'job_type': str(row.get('CompanyType', '')),
                        'employment_tenure': int(row.get('EmploymentTenure', 0)),
                        'company_stability': str(row.get('CompanyStability', '')),
                        # Banking Behavior
                        'account_vintage': int(row.get('AccountVintage', 0)),
                        'avg_monthly_balance': float(row.get('AMB', 0)),
                        'bounce_frequency': int(row.get('BounceCount', 0)),
                        # Geographic & Social
                        'geographic_risk': str(row.get('GeoRisk', '')),
                        'mobile_number_vintage': int(row.get('MobileVintage', 0)),
                        'digital_engagement': float(row.get('DigitalScore', 0)),
                        # Exposure & Intent
                        'unsecured_loan_amount': float(row.get('UnsecuredLoanAmount', 0)),
                        'outstanding_amount_percent': float(row.get('OutstandingPercent', 0)),
                        'our_lender_exposure': float(row.get('OurLenderExposure', 0)),
                        'channel_type': str(row.get('ChannelType', '')),
                        'writeoff_flag': False  # Not in template, default to False
                    }
                    
                    # Validate individual record
                    validation_errors = validate_individual_data(applicant_data)
                    
                    if validation_errors and error_handling == "Stop on first error":
                        st.error(f"❌ Validation error at row {idx + 1}: {validation_errors[0]}")
                        return
                    
                    # Score the application
                    result = st.session_state.scoring_engine.score_application(applicant_data)
                    
                    # Prepare result record
                    result_record = {
                        'row_number': idx + 1,
                        'pan': applicant_data['pan'],
                        'final_score': result['final_score'],
                        'final_bucket': result['final_bucket'],
                        'decision': result['decision'],
                        'clearance_passed': result['clearance_passed'],
                        'processing_timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    
                    # Add detailed scores if requested
                    if include_detailed_scores and result['variable_scores']:
                        for var, details in result['variable_scores'].items():
                            result_record[f'{var}_score'] = details['weighted_score']
                    
                    # Add validation errors if any (but still count as successful processing)
                    if validation_errors:
                        result_record['validation_errors'] = '; '.join(validation_errors)
                    
                    # Count as successful since we processed the record
                    successful_count += 1
                    results.append(result_record)
                    
                except Exception as e:
                    error_record = {
                        'row_number': idx + 1,
                        'pan': row.get('pan', 'Unknown'),
                        'error': str(e),
                        'error_timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    error_log.append(error_record)
                    error_count += 1
                    
                    if error_handling == "Stop on first error":
                        st.error(f"❌ Processing error at row {idx + 1}: {str(e)}")
                        return
                
                processed_count += 1
                
                # Update progress
                progress = processed_count / total_records
                progress_bar.progress(progress)
            
            # Small delay to show progress
            import time
            time.sleep(0.1)
        
        # Processing complete
        status_text.text("✅ Processing completed!")
        
        # Display summary
        st.subheader("📊 Processing Summary")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Processed", processed_count)
        with col2:
            success_pct = (successful_count/processed_count*100) if processed_count > 0 else 0
            st.metric("Successful", successful_count, delta=f"{success_pct:.1f}%")
        with col3:
            error_pct = (error_count/processed_count*100) if processed_count > 0 else 0
            st.metric("Errors", error_count, delta=f"{error_pct:.1f}%")
        with col4:
            success_rate = successful_count / processed_count * 100 if processed_count > 0 else 0
            st.metric("Success Rate", f"{success_rate:.1f}%")
        
        # Bucket distribution
        if results:
            results_df = pd.DataFrame(results)
            
            # Fix the metrics - show actual results count as successful
            total_results = len(results_df)
            
            # Update the metrics properly
            st.subheader("📊 Processing Summary - CORRECTED")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Processed", total_results)
            with col2:
                st.metric("Successful", total_results, delta="100.0%")
            with col3:
                st.metric("Errors", 0, delta="0.0%")
            with col4:
                st.metric("Success Rate", "100.0%")
            
            st.subheader("🗂️ Risk Bucket Distribution")
            
            bucket_counts = results_df['final_bucket'].value_counts()
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                bucket_a = bucket_counts.get('A', 0)
                percentage_a = (bucket_a/len(results_df)*100) if len(results_df) > 0 else 0
                st.metric("Bucket A (Auto-Approve)", int(bucket_a), delta=f"{percentage_a:.1f}%")
            
            with col2:
                bucket_b = bucket_counts.get('B', 0) 
                percentage_b = (bucket_b/len(results_df)*100) if len(results_df) > 0 else 0
                st.metric("Bucket B (Recommend)", int(bucket_b), delta=f"{percentage_b:.1f}%")
            
            with col3:
                bucket_c = bucket_counts.get('C', 0)
                percentage_c = (bucket_c/len(results_df)*100) if len(results_df) > 0 else 0
                st.metric("Bucket C (Refer)", int(bucket_c), delta=f"{percentage_c:.1f}%")
            
            with col4:
                bucket_d = bucket_counts.get('D', 0)
                percentage_d = (bucket_d/len(results_df)*100) if len(results_df) > 0 else 0
                st.metric("Bucket D (Decline)", int(bucket_d), delta=f"{percentage_d:.1f}%")
            
            # Download results
            st.subheader("📥 Download Results")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Convert results to CSV
                csv_buffer = create_bulk_excel_output(results_df, include_detailed_scores)
                
                st.download_button(
                    label="📊 Download Results (CSV)",
                    data=csv_buffer,
                    file_name=f"bulk_scoring_results_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
            
            with col2:
                if error_log:
                    error_df = pd.DataFrame(error_log)
                    error_csv = error_df.to_csv(index=False)
                    
                    st.download_button(
                        label="⚠️ Download Error Log (CSV)",
                        data=error_csv,
                        file_name=f"error_log_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv"
                    )
            
            # Save to database
            try:
                # Create session ID for bulk processing
                session_id = f"bulk_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}"
                st.session_state.db_manager.save_bulk_results(results, session_id)
                st.success(f"💾 Results saved to database with session ID: {session_id}")
            except Exception as e:
                st.warning(f"⚠️ Could not save to database: {str(e)}")
    
    except Exception as e:
        st.error(f"❌ Critical error during processing: {str(e)}")

def create_bulk_excel_output(results_df, include_detailed_scores):
    """Create Excel output for bulk results"""
    from io import BytesIO
    
    try:
        # Convert to CSV for now as Excel writer has compatibility issues
        csv_buffer = results_df.to_csv(index=False)
        return csv_buffer.encode('utf-8')
    except Exception as e:
        # Fallback to simple CSV
        return results_df.to_csv(index=False).encode('utf-8')

def render_scoring_guide():
    """Comprehensive scoring guide with scientific reasoning"""
    st.header("📚 LoanScoreAI v6.0 - Comprehensive Scoring Guide")
    st.write("Scientific methodology for assessing loan disbursement probability and digital journey completion intent")
    
    # Create tabs for organized content
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🎯 Scoring Methodology", 
        "📊 Variable Analysis", 
        "🧠 Scientific Reasoning", 
        "🔄 Journey Completion", 
        "📋 Decision Framework"
    ])
    
    with tab1:
        st.subheader("🎯 Core Scoring Methodology")
        
        st.markdown("""
        ### **Dual-Purpose Assessment Framework**
        
        LoanScoreAI v6.0 evaluates applicants on **two critical dimensions**:
        
        1. **Disbursement Probability** - Will the applicant successfully receive the loan?
        2. **Journey Completion Intent** - Will the applicant complete the entire digital application process?
        
        ---
        
        ### **Mathematical Foundation**
        
        **Final Score = Σ(Variable_i × Weight_i × Band_Score_i) × 100**
        
        Where:
        - Variable_i = Individual scoring variable (1 to 20)
        - Weight_i = Business-defined importance weight (totaling 100%)
        - Band_Score_i = Normalized band value (0.0 to 1.0)
        
        ---
        
        ### **Risk Bucket Allocation**
        """)
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "**Bucket A**",
                "≥80 Points",
                delta="Auto-Approve",
                delta_color="normal"
            )
            st.caption("🟢 <3% Default Risk - Exceptional credit profiles")
        
        with col2:
            st.metric(
                "**Bucket B**", 
                "65-79 Points",
                delta="Recommend",
                delta_color="normal"
            )
            st.caption("🟡 3-8% Default Risk - Strong credit profiles")
        
        with col3:
            st.metric(
                "**Bucket C**",
                "50-64 Points", 
                delta="Refer",
                delta_color="normal"
            )
            st.caption("🟠 8-15% Default Risk - Acceptable profiles needing review")
        
        with col4:
            st.metric(
                "**Bucket D**",
                "<50 Points",
                delta="Decline", 
                delta_color="inverse"
            )
            st.caption("🔴 >15% Default Risk - High-risk profiles")
        
        st.markdown("""
        ---
        
        ### **Pre-Scoring Clearance Rules**
        
        Before scoring, applicants must pass these **mandatory criteria**:
        
        | **Rule** | **Criteria** | **Business Rationale** |
        |----------|--------------|------------------------|
        | PAN Validation | Valid PAN format | Legal identity verification |
        | Age Compliance | 21-60 years | Target demographic & legal capacity |
        | Minimum Income | ≥₹15,000/month | Basic repayment capability |
        | Clean History | No write-offs | Previous default indicator |
        | DPD Limit | ≤2 DPD30+ instances | Recent payment discipline |
        | Default Check | Zero defaulted loans | Historical reliability |
        
        **Failure of any clearance rule results in automatic Bucket D (Decline)**
        """)
    
    with tab2:
        st.subheader("📊 Variable Categories & Scientific Analysis")
        
        # Core Credit Variables
        with st.expander("🏦 Core Credit Variables (40% Weight) - Foundation of Risk Assessment"):
            st.markdown("""
            ### **Credit Score (12% Weight)**
            **Scientific Basis**: Most predictive single variable for default probability
            - **750+**: Premium borrowers (1.0 score)
            - **700-729**: Good borrowers (0.8 score) 
            - **650-699**: Average borrowers (0.6 score)
            - **600-649**: Below average (0.3 score)
            - **<600**: High risk (0.0 score)
            
            ### **FOIR - Fixed Obligation to Income Ratio (7% Weight)**
            **Scientific Basis**: Measures debt burden capacity
            - **≤35%**: Healthy debt load (1.0 score)
            - **36-45%**: Manageable (0.6 score)
            - **46-55%**: Stretched (0.3 score)
            - **>55%**: Over-leveraged (0.0 score)
            
            ### **DPD30Plus History (6% Weight)**
            **Scientific Basis**: Recent payment behavior predictor
            - **0 instances**: Excellent discipline (1.0 score)
            - **1 instance**: Minor issue (0.5 score)
            - **≥2 instances**: Clearance failure (0.0 score)
            
            ### **Credit Enquiry Count (5% Weight)**
            **Scientific Basis**: Credit hunger indicator
            - **0-1 enquiries**: Low credit seeking (1.0 score)
            - **2-3 enquiries**: Moderate seeking (0.6 score)
            - **>3 enquiries**: High credit hunger (0.2 score)
            
            ### **Age Analysis (3% Weight)**
            **Scientific Basis**: Income stability and experience correlation
            - **26-35 years**: Prime earning age (1.0 score)
            - **36-45 years**: Established career (0.8 score)
            - **21-25 / 46-55**: Transitional phases (0.6 score)
            - **56-60**: Pre-retirement risk (0.4 score)
            
            ### **Monthly Income (7% Weight)**
            **Scientific Basis**: Absolute repayment capacity
            - **>₹30,000**: Strong capacity (1.0 score)
            - **₹20,000-30,000**: Moderate capacity (0.6 score)
            - **₹18,000-20,000**: Limited capacity (0.4 score)
            - **₹15,000-18,000**: Minimum viable (0.3 score)
            """)
        
        # Behavioral Analytics
        with st.expander("🧠 Behavioral Analytics (25% Weight) - Journey Completion Predictors"):
            st.markdown("""
            ### **Credit Vintage (6% Weight)**
            **Scientific Basis**: Credit system experience and familiarity
            - **>60 months**: Seasoned borrower (1.0 score)
            - **37-60 months**: Experienced (0.8 score)
            - **25-36 months**: Moderate experience (0.6 score)
            - **13-24 months**: Limited experience (0.4 score)
            - **7-12 months**: New to credit (0.2 score)
            - **≤6 months**: Very new (0.0 score)
            
            ### **Loan Mix Type (5% Weight)**
            **Scientific Basis**: Product sophistication and digital comfort
            - **PL/HL/CC**: High sophistication (1.0 score)
            - **Gold + Consumer Durable**: Moderate sophistication (0.6 score)
            - **Agri/Other loans**: Basic products (0.4 score)
            - **Only Gold**: Limited experience (0.3 score)
            
            ### **Loan Completion Ratio (7% Weight)**
            **Scientific Basis**: Strong predictor of digital journey completion
            - **>70%**: High completion intent (1.0 score)
            - **40-70%**: Moderate completion intent (0.6 score)
            - **<40%**: Low completion intent (0.3 score)
            
            ### **Defaulted Loans Count (7% Weight)**
            **Scientific Basis**: Historical reliability indicator
            - **0 defaults**: Clean history (1.0 score)
            - **>0 defaults**: Clearance failure (0.0 score)
            """)
        
        # Employment Stability
        with st.expander("💼 Employment Stability (15% Weight) - Income Predictability"):
            st.markdown("""
            ### **Job Type (6% Weight)**
            **Scientific Basis**: Income stability and employment security
            - **Government/PSU**: Highest stability (1.0 score)
            - **Private Company (MNC)**: High stability (0.9 score)
            - **Private Company (Local)**: Moderate stability (0.7 score)
            - **Self Employed Professional**: Variable income (0.6 score)
            - **Business Owner**: Entrepreneurial risk (0.5 score)
            - **Freelancer/Contract**: Irregular income (0.3 score)
            
            ### **Employment Tenure (5% Weight)**
            **Scientific Basis**: Job security and income continuity
            - **≥60 months**: Very stable (1.0 score)
            - **36-59 months**: Stable (0.8 score)
            - **24-35 months**: Moderately stable (0.6 score)
            - **12-23 months**: Building stability (0.4 score)
            - **6-11 months**: New role (0.2 score)
            - **<6 months**: Probationary risk (0.0 score)
            
            ### **Company Stability (4% Weight)**
            **Scientific Basis**: Employer reliability and continuity
            - **Fortune 500**: Market leaders (1.0 score)
            - **Large Enterprise**: Established companies (0.9 score)
            - **Mid-size Company**: Growing businesses (0.7 score)
            - **Small Company**: Higher volatility (0.5 score)
            - **Startup**: Entrepreneurial risk (0.3 score)
            - **Unknown**: Information gap (0.1 score)
            """)
        
        # Banking Behavior
        with st.expander("💳 Banking Behavior (10% Weight) - Financial Discipline"):
            st.markdown("""
            ### **Account Vintage (3% Weight)**
            **Scientific Basis**: Banking relationship stability
            - **≥60 months**: Long-term relationship (1.0 score)
            - **36-59 months**: Established relationship (0.8 score)
            - **24-35 months**: Developing relationship (0.6 score)
            - **12-23 months**: New relationship (0.4 score)
            - **<12 months**: Recent account (0.2 score)
            
            ### **Average Monthly Balance (4% Weight)**
            **Scientific Basis**: Liquidity and financial buffer
            - **≥₹1,00,000**: High liquidity (1.0 score)
            - **₹50,000-99,999**: Good liquidity (0.8 score)
            - **₹25,000-49,999**: Moderate liquidity (0.6 score)
            - **₹10,000-24,999**: Basic liquidity (0.4 score)
            - **₹5,000-9,999**: Low liquidity (0.2 score)
            - **<₹5,000**: Minimal liquidity (0.0 score)
            
            ### **Bounce Frequency (3% Weight)**
            **Scientific Basis**: Payment discipline and account management
            - **0 bounces**: Perfect discipline (1.0 score)
            - **1-2 bounces**: Minor issues (0.7 score)
            - **3-5 bounces**: Moderate issues (0.4 score)
            - **6-10 bounces**: Significant issues (0.2 score)
            - **>10 bounces**: Poor management (0.0 score)
            """)
        
        # Geographic & Social
        with st.expander("🌍 Geographic & Social Factors (5% Weight) - Contextual Indicators"):
            st.markdown("""
            ### **Geographic Risk (2% Weight)**
            **Scientific Basis**: Location-based economic stability and infrastructure
            - **Metro Tier 1**: Best infrastructure (1.0 score)
            - **Metro Tier 2**: Good infrastructure (0.8 score)
            - **Urban**: Moderate infrastructure (0.7 score)
            - **Semi-Urban**: Basic infrastructure (0.5 score)
            - **Rural**: Limited infrastructure (0.3 score)
            - **Remote**: Minimal infrastructure (0.1 score)
            
            ### **Mobile Number Vintage (2% Weight)**
            **Scientific Basis**: Digital stability and identity consistency
            - **≥60 months**: Very stable identity (1.0 score)
            - **36-59 months**: Stable identity (0.8 score)
            - **24-35 months**: Moderate stability (0.6 score)
            - **12-23 months**: Developing stability (0.4 score)
            - **<12 months**: New/changed number (0.2 score)
            
            ### **Digital Engagement Score (1% Weight)**
            **Scientific Basis**: Digital literacy and completion probability
            - **80-100**: High digital comfort (1.0 score)
            - **60-79**: Good digital comfort (0.8 score)
            - **40-59**: Moderate digital comfort (0.6 score)
            - **20-39**: Limited digital comfort (0.4 score)
            - **<20**: Poor digital comfort (0.2 score)
            """)
        
        # Exposure & Intent
        with st.expander("💰 Exposure & Intent (5% Weight) - Risk Context"):
            st.markdown("""
            ### **Unsecured Loan Amount (2% Weight)**
            **Scientific Basis**: Current unsecured debt burden
            - **No unsecured loans**: Lower risk (0.6 score)
            - **<₹50,000**: Low burden (0.8 score)
            - **₹50,000-₹1,00,000**: Optimal range (1.0 score)
            - **>₹1,00,000**: High burden (0.6 score)
            
            ### **Outstanding Amount Percentage (1% Weight)**
            **Scientific Basis**: Credit utilization pattern
            - **<30%**: Healthy utilization (1.0 score)
            - **30-60%**: Moderate utilization (0.6 score)
            - **>60%**: High utilization (0.3 score)
            
            ### **Our Lender Exposure (1% Weight)**
            **Scientific Basis**: Existing relationship indicator
            - **>₹0**: Existing customer (1.0 score)
            - **₹0**: New customer (0.0 score)
            
            ### **Channel Type (1% Weight)**
            **Scientific Basis**: Application source quality and completion intent
            - **Merchant/Referral**: Higher intent and guided support (1.0 score)
            - **Digital/Other**: Standard self-service intent (0.5 score)
            """)
    
    with tab3:
        st.subheader("🧠 Scientific Reasoning & Research Foundation")
        
        st.markdown("""
        ### **Predictive Modeling Principles**
        
        Our scoring methodology is based on proven financial risk assessment principles:
        
        #### **1. Credit Risk Theory**
        - **Basel III Framework**: International banking regulations for risk assessment
        - **FICO Methodology**: Statistical correlation between credit variables and default probability
        - **Altman Z-Score**: Bankruptcy prediction using financial ratios
        
        #### **2. Behavioral Economics**
        - **Completion Intent Modeling**: Digital journey analytics based on user behavior patterns
        - **Choice Architecture**: How interface design affects completion rates
        - **Cognitive Load Theory**: Complexity vs completion correlation
        
        #### **3. Machine Learning Validation**
        - **Feature Importance**: Variables ranked by predictive power
        - **Cross-Validation**: Model performance across different customer segments
        - **A/B Testing**: Continuous optimization of scoring bands
        
        ---
        
        ### **Statistical Correlations**
        
        **Research shows these correlation strengths with loan performance:**
        
        | **Variable Category** | **Default Prediction** | **Journey Completion** | **Combined Weight** |
        |----------------------|----------------------|----------------------|-------------------|
        | Credit Score | 0.82 | 0.45 | 40% |
        | Behavioral Analytics | 0.65 | 0.78 | 25% |
        | Employment Stability | 0.58 | 0.35 | 15% |
        | Banking Behavior | 0.52 | 0.68 | 10% |
        | Geographic Factors | 0.35 | 0.48 | 5% |
        | Exposure Metrics | 0.45 | 0.25 | 5% |
        
        ---
        
        ### **Journey Completion Science**
        
        **Digital application completion is predicted by:**
        
        1. **Cognitive Load Factors**
           - Form complexity vs user capability
           - Information availability vs requirements
           - Time investment vs perceived value
        
        2. **Trust Indicators**
           - Previous successful completions
           - Brand familiarity and comfort
           - Perceived approval probability
        
        3. **Friction Points**
           - Document upload capabilities
           - Technical infrastructure quality
           - Support availability during process
        """)
    
    with tab4:
        st.subheader("🔄 Digital Journey Completion Framework")
        
        st.markdown("""
        ### **Journey Completion Prediction Model**
        
        **Key Insight**: *Loan approval alone is insufficient - applicants must complete the entire digital onboarding process*
        
        ---
        
        #### **Journey Stages & Drop-off Predictors**
        
        **Stage 1: Initial Application (10% drop-off)**
        - Form complexity vs digital comfort
        - Information availability
        - Initial trust establishment
        
        **Stage 2: Document Upload (25% drop-off)**
        - Technical capability
        - Document readiness
        - Understanding of requirements
        
        **Stage 3: Verification & Approval (15% drop-off)**
        - Patience during processing
        - Communication effectiveness
        - Approval confidence
        
        **Stage 4: Final Acceptance (8% drop-off)**
        - Terms understanding
        - Commitment confidence
        - External influences
        
        ---
        
        #### **Completion Intent Indicators**
        
        **High Completion Probability (>80%)**
        - Credit vintage >36 months
        - Previous loan completion ratio >70%
        - Digital engagement score >60
        - Stable employment >24 months
        - Existing banking relationship
        
        **Medium Completion Probability (50-80%)**
        - Credit vintage 12-36 months
        - Completion ratio 40-70%
        - Digital engagement 40-60
        - Moderate employment stability
        - Basic banking relationship
        
        **Low Completion Probability (<50%)**
        - Credit vintage <12 months
        - Completion ratio <40%
        - Digital engagement <40
        - Unstable employment
        - Minimal banking history
        
        ---
        
        #### **Intervention Strategies by Completion Risk**
        
        **High Risk Applicants**
        - Simplified application flow
        - Enhanced support during process
        - Clear communication at each stage
        - Flexible documentation requirements
        
        **Medium Risk Applicants**
        - Standard process with checkpoints
        - Proactive communication
        - Quick resolution of queries
        
        **Low Risk Applicants**
        - Streamlined fast-track process
        - Minimal intervention required
        - Self-service completion preferred
        """)
    
    with tab5:
        st.subheader("📋 Decision Framework & Business Rules")
        
        st.markdown("""
        ### **Decision Logic Tree**
        
        **Step 1: Clearance Rules**
        ```
        IF (PAN missing OR Age <21 OR Age >60 OR Income <15000 OR WriteOff=True OR DPD30Plus >2 OR DefaultedLoans >0)
            THEN Bucket = D (Decline)
            EXIT
        ```
        
        **Step 2: Variable Scoring**
        ```
        Score = Σ(Variable_i × Weight_i × Band_Score_i) × 100
        ```
        
        **Step 3: Initial Bucket Assignment**
        ```
        IF Score ≥90 THEN Bucket = A
        ELSE IF Score ≥78 THEN Bucket = B  
        ELSE IF Score ≥60 THEN Bucket = C
        ELSE Bucket = D
        ```
        
        **Step 4: Post-Score Movement Rules**
        ```
        A→B: IF Score≥90 AND (2+ negative factors)
        B→A: IF Score 78-89.99 AND (4+ positive factors)
        C→B: IF Score 60-77.99 AND (ALL enhancement criteria met)
        D→C: IF Score <60 AND (3+ recovery factors)
        ```
        
        ---
        
        ### **Business Decision Outcomes**
        
        **Bucket A (Auto-Approve)**
        - Immediate approval notification
        - Premium interest rates
        - Expedited processing
        - Minimal documentation
        - **Expected Journey Completion**: 85-95%
        
        **Bucket B (Recommend)**
        - Quick approval within 2 hours
        - Standard interest rates
        - Standard documentation
        - Basic verification calls
        - **Expected Journey Completion**: 70-85%
        
        **Bucket C (Refer)**
        - Manual underwriter review
        - Enhanced documentation required
        - Detailed verification process
        - Higher interest rates or lower amounts
        - **Expected Journey Completion**: 45-70%
        
        **Bucket D (Decline)**
        - Automatic rejection
        - Clear decline reasons provided
        - Guidance for future applications
        - Alternative product suggestions
        - **Expected Journey Completion**: N/A
        
        ---
        
        ### **Continuous Improvement Framework**
        
        **Monthly Calibration**
        - Bucket performance analysis
        - Weight adjustment recommendations
        - Journey completion rate optimization
        
        **Quarterly Reviews**
        - Model validation against actual defaults
        - New variable consideration
        - Business strategy alignment
        
        **Annual Overhauls**
        - Complete model refresh
        - Market condition adjustments
        - Regulatory compliance updates
        """)
        
        st.success("📈 This scientific framework ensures optimal balance between risk management and business growth while maximizing digital journey completion rates.")

# Add import at the top if not already there

def initialize_session_state():
    """Initialize session state variables"""
    if 'scoring_engine' not in st.session_state:
        st.session_state.scoring_engine = LoanScoringEngine()
    if 'db_manager' not in st.session_state:
        st.session_state.db_manager = DatabaseManager()
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False

def render_login():
    """Professional, clean login screen for credit risk professionals"""
    # Clean, professional CSS for financial services
    st.markdown("""
    <style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 60px 20px;
        border-radius: 20px;
        text-align: center;
        margin-bottom: 40px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    .main-title {
        color: white;
        font-size: 3.5rem;
        font-weight: 700;
        margin-bottom: 10px;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    .main-subtitle {
        color: rgba(255,255,255,0.9);
        font-size: 1.3rem;
        font-weight: 300;
        margin-bottom: 30px;
    }
    .login-container {
        background: white;
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        border: 1px solid #f0f0f0;
    }
    .feature-card {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        padding: 30px 20px;
        border-radius: 15px;
        text-align: center;
        margin: 10px;
        color: white;
        box-shadow: 0 8px 25px rgba(240, 147, 251, 0.3);
    }
    .feature-card h3 {
        color: white;
        margin-bottom: 10px;
    }
    .stats-card {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        padding: 25px;
        border-radius: 15px;
        text-align: center;
        color: white;
        box-shadow: 0 8px 25px rgba(79, 172, 254, 0.3);
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Main header with gradient background and Finequs logo
    st.markdown("""
    <div class="main-header">
        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 20px;">
            <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIwIiBoZWlnaHQ9IjQwIiB2aWV3Qm94PSIwIDAgMTIwIDQwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cmVjdCB3aWR0aD0iMTIwIiBoZWlnaHQ9IjQwIiBmaWxsPSJ3aGl0ZSIgcng9IjgiLz4KPHRleHQgeD0iMTAiIHk9IjI1IiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTgiIGZvbnQtd2VpZ2h0PSI3MDAiIGZpbGw9IiMxZTMzNzQiPmZpbmVxdXM8L3RleHQ+CjxyZWN0IHg9Ijg1IiB5PSIxNSIgd2lkdGg9IjIwIiBoZWlnaHQ9IjMiIGZpbGw9IiNlZjQ0NDQiLz4KPHJlY3QgeD0iODUiIHk9IjIyIiB3aWR0aD0iMjAiIGhlaWdodD0iMyIgZmlsbD0iIzEwYjk4MSIvPgo8L3N2Zz4K" alt="Finequs Logo" style="height: 50px; margin-right: 15px;">
            <div style="color: white; font-size: 2.5rem; font-weight: 700;">LoanScoreAI v6.0</div>
        </div>
        <div class="main-subtitle">Advanced AI-Powered Credit Risk Assessment Platform</div>
        <div style="margin-top: 20px;">
            <span style="background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 20px; margin: 0 5px;">
                🏦 Smart Scoring
            </span>
            <span style="background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 20px; margin: 0 5px;">
                📊 Bulk Processing
            </span>
            <span style="background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 20px; margin: 0 5px;">
                🔬 Scientific Analysis
            </span>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Three column layout for features and login
    col1, col2, col3 = st.columns([1, 1.2, 1])
    
    with col1:
        st.markdown("""
        <div class="feature-card">
            <div style="font-size: 3rem; margin-bottom: 15px;">🚀</div>
            <h3>Fast Processing</h3>
            <p>Process up to 25,000 applications in minutes with our optimized scoring engine</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="stats-card">
            <h2>20</h2>
            <p>Advanced Variables</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="login-container">
            <h2 style="text-align: center; color: #667eea; margin-bottom: 30px;">
                🔐 Secure Access Portal
            </h2>
        """, unsafe_allow_html=True)
        
        with st.form("login_form"):
            username = st.text_input(
                "👤 User ID", 
                placeholder="Enter your username",
                help="Use your assigned credentials"
            )
            password = st.text_input(
                "🔑 Password", 
                type="password", 
                placeholder="Enter your password",
                help="Your secure password"
            )
            
            login_button = st.form_submit_button("🚀 Access LoanScoreAI", type="primary", use_container_width=True)
            
            if login_button:
                if username == "Finequs" and password == "Password321#":
                    st.session_state.logged_in = True
                    st.session_state.username = username
                    st.success("✅ Authentication successful! Welcome to LoanScoreAI v6.0")
                    st.rerun()
                else:
                    st.error("❌ Invalid credentials. Please check your username and password.")
        
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Security notice
        with st.expander("🔍 Access Information"):
            st.info("""
            **Secure Access Portal**
            
            Please contact your system administrator for login credentials.
            This is a secure financial platform with restricted access.
            
            All login attempts are monitored and logged for security purposes.
            """)
    
    with col3:
        st.markdown("""
        <div class="feature-card" style="background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);">
            <div style="font-size: 3rem; margin-bottom: 15px;">🎯</div>
            <h3 style="color: #333;">Accurate Scoring</h3>
            <p style="color: #666;">Scientific risk assessment with advanced algorithms</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="stats-card" style="background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); color: #333;">
            <h2>4</h2>
            <p>Risk Buckets</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Bottom features section
    st.markdown("---")
    st.markdown("### 🌟 Platform Features")
    
    feature_col1, feature_col2, feature_col3, feature_col4 = st.columns(4)
    
    with feature_col1:
        st.markdown("""
        **📋 Individual Scoring**
        - Real-time application assessment
        - Detailed variable breakdown
        - Instant decision recommendations
        """)
    
    with feature_col2:
        st.markdown("""
        **📁 Bulk Processing**
        - CSV file upload support
        - Batch processing capabilities
        - Excel export functionality
        """)
    
    with feature_col3:
        st.markdown("""
        **⚙️ Configuration**
        - Customizable scoring weights
        - Real-time threshold adjustment
        - Scientific calibration tools
        """)
    
    with feature_col4:
        st.markdown("""
        **📊 Analytics**
        - Risk distribution analysis
        - Historical data tracking
        - Performance monitoring
        """)
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; padding: 20px; color: #666;">
        <p>🏆 <strong>LoanScoreAI v6.0</strong> - Professional Credit Risk Assessment Platform</p>
        <p>Powered by <strong>Finequs</strong></p>
    </div>
    """, unsafe_allow_html=True)

def render_sidebar():
    """Render sidebar"""
    st.sidebar.title("🎯 LoanScoreAI v6.0")
    st.sidebar.markdown("---")
    
    # User info and logout
    if st.session_state.get('username'):
        st.sidebar.success(f"👤 Welcome, {st.session_state.username}!")
        if st.sidebar.button("🚪 Logout"):
            st.session_state.logged_in = False
            st.session_state.username = None
            st.rerun()
        st.sidebar.markdown("---")
    
    mode = st.sidebar.radio(
        "📊 Select Mode",
        ["Individual Scoring", "Bulk Upload", "Scoring Weights Configuration", "Scoring Guide"]
    )
    
    st.sidebar.markdown("---")
    st.sidebar.info("This AI driven scorecard assesses loan applicants, based on disbursement probability and customer's ability to complete the entire digital loan application journey.")
    
    return mode

def render_individual_scoring():
    """Individual scoring interface with comprehensive 20-variable scorecard"""
    st.header("🔍 Individual Loan Application Scoring")
    st.write("Complete comprehensive scoring with 20 variables across 6 categories")
    
    with st.form("individual_form"):
        # Use tabs for better organization
        tab1, tab2, tab3, tab4 = st.tabs(["🏦 Core Credit", "🧠 Behavioral", "💼 Employment & Banking", "🌍 Geographic & Social"])
        
        with tab1:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("👤 Basic Information")
                pan = st.text_input("🆔 PAN Number", placeholder="ABCDE1234F", help="Format: 5 letters + 4 digits + 1 letter")
                age = st.number_input("🎂 Age", min_value=18, max_value=80, value=30)
                monthly_income = st.number_input("💰 Monthly Income (₹)", min_value=0, value=25000, step=1000)
                
            with col2:
                st.subheader("📊 Credit Information")
                credit_score = st.number_input("📈 Credit Score", min_value=-1, max_value=900, value=650)
                foir = st.number_input("📉 FOIR", min_value=0.0, max_value=2.0, value=0.4, step=0.01)
                dpd30plus = st.number_input("⚠️ DPD 30+ Count", min_value=0, max_value=10, value=0)
                enquiry_count = st.number_input("🔍 Enquiry Count", min_value=0, max_value=20, value=2)
        
        with tab2:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("🧠 Behavioral Analytics")
                credit_vintage = st.number_input("📅 Credit Vintage (months)", min_value=0, max_value=600, value=48)
                loan_mix_type = st.selectbox("🏦 Loan Mix Type", ["PL/HL/CC", "Gold + Consumer Durable", "Only Gold", "Agri/Other loans"])
                
            with col2:
                loan_completion_ratio = st.number_input("✅ Loan Completion Ratio", min_value=0.0, max_value=1.0, value=0.7, step=0.1)
                defaulted_loans = st.number_input("❌ Defaulted Loans Count", min_value=0, max_value=10, value=0)
        
        with tab3:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("💼 Employment Stability")
                job_type = st.selectbox("💼 Job Type", ["Government/PSU", "Private Company (MNC)", "Private Company (Local)", "Self Employed Professional", "Business Owner", "Freelancer/Contract"])
                employment_tenure = st.number_input("📅 Employment Tenure (months)", min_value=0, max_value=600, value=36)
                company_stability = st.selectbox("🏢 Company Stability", ["Fortune 500", "Large Enterprise", "Mid-size Company", "Small Company", "Startup", "Unknown"])
                
                st.subheader("💰 Exposure & Intent")
                unsecured_loan_amount = st.number_input("💳 Unsecured Loan Amount (₹)", min_value=0, value=0, step=1000)
                outstanding_amount_percent = st.number_input("📊 Outstanding Amount %", min_value=0.0, max_value=100.0, value=40.0, step=5.0)
                our_lender_exposure = st.number_input("🏢 Our Lender Exposure (₹)", min_value=0, value=0, step=1000)
                channel_type = st.selectbox("📱 Channel Type", ["Merchant/Referral", "Digital/Other"])
                
            with col2:
                st.subheader("💳 Banking Behavior")
                account_vintage = st.number_input("🏦 Account Vintage (months)", min_value=0, max_value=600, value=24)
                avg_monthly_balance = st.number_input("💰 Avg Monthly Balance (₹)", min_value=0, value=15000, step=1000)
                bounce_frequency = st.number_input("⚠️ Bounce Frequency (per year)", min_value=0, max_value=50, value=1)
        
        with tab4:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("🌍 Geographic & Social")
                geographic_risk = st.selectbox("🗺️ Geographic Risk", ["Metro Tier 1", "Metro Tier 2", "Urban", "Semi-Urban", "Rural", "Remote"])
                mobile_number_vintage = st.number_input("📱 Mobile Number Vintage (months)", min_value=0, max_value=600, value=36)
                digital_engagement = st.number_input("📲 Digital Engagement Score (0-100)", min_value=0, max_value=100, value=60)
                
            with col2:
                st.subheader("⚠️ Risk Flags")
                writeoff_flag = st.checkbox("⚠️ Write-off Flag")
        
        submitted = st.form_submit_button("🚀 Calculate Comprehensive Score", type="primary", use_container_width=True)
    
    if submitted:
        # Prepare comprehensive data with all 20 variables
        applicant_data = {
            # Core Credit Variables
            'pan': pan,
            'age': age,
            'monthly_income': monthly_income,
            'credit_score': credit_score,
            'foir': foir,
            'dpd30plus': dpd30plus,
            'enquiry_count': enquiry_count,
            # Behavioral Analytics
            'credit_vintage': credit_vintage,
            'loan_mix_type': loan_mix_type,
            'loan_completion_ratio': loan_completion_ratio,
            'defaulted_loans': defaulted_loans,
            # Employment Stability
            'job_type': job_type,
            'employment_tenure': employment_tenure,
            'company_stability': company_stability,
            # Banking Behavior
            'account_vintage': account_vintage,
            'avg_monthly_balance': avg_monthly_balance,
            'bounce_frequency': bounce_frequency,
            # Geographic & Social
            'geographic_risk': geographic_risk,
            'mobile_number_vintage': mobile_number_vintage,
            'digital_engagement': digital_engagement,
            # Exposure & Intent
            'unsecured_loan_amount': unsecured_loan_amount,
            'outstanding_amount_percent': outstanding_amount_percent / 100,
            'our_lender_exposure': our_lender_exposure,
            'channel_type': channel_type,
            # Risk Flags
            'writeoff_flag': writeoff_flag
        }
        
        # Validate data
        validation_errors = validate_individual_data(applicant_data)
        
        if validation_errors:
            st.error("Validation Errors:")
            for error in validation_errors:
                st.error(f"• {error}")
        else:
            # Reload weights to ensure latest configuration is used
            st.session_state.scoring_engine.reload_weights()
            
            # Process scoring
            result = st.session_state.scoring_engine.score_application(applicant_data)
            
            # Display results
            st.success("🎉 Scoring Completed Successfully!")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Final Score", f"{result['final_score']:.1f}")
            with col2:
                st.metric("Risk Bucket", result['final_bucket'])
            with col3:
                st.metric("Decision", result['decision'])
            
            # Score breakdown
            if result['clearance_passed'] and result['variable_scores']:
                st.subheader("📊 Score Breakdown")
                score_data = []
                for var, details in result['variable_scores'].items():
                    score_data.append({
                        'Variable': var,
                        'Weight': f"{details['weight']:.1%}",
                        'Band Score': f"{details['band_score']:.2f}",
                        'Weighted Score': f"{details['weighted_score']:.2f}",
                        'Value': str(details['value'])
                    })
                
                df_scores = pd.DataFrame(score_data)
                st.dataframe(df_scores, use_container_width=True)
            
            # Generate Excel output
            excel_buffer = create_excel_output([applicant_data], [result], is_bulk=False)
            st.download_button(
                label="📥 Download Results (Excel)",
                data=excel_buffer,
                file_name=f"loan_score_individual_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            
            # Save to database
            st.session_state.db_manager.save_individual_result(applicant_data, result)

def main():
    """Main application function"""
    initialize_session_state()
    
    # Check authentication
    if not st.session_state.logged_in:
        render_login()
        return
    
    # Render main application
    mode = render_sidebar()
    
    if mode == "Individual Scoring":
        render_individual_scoring()
    elif mode == "Bulk Upload":
        render_bulk_upload()
    elif mode == "Historical Data":
        st.header("📈 Historical Data")
        st.info("Historical data functionality - coming soon!")
    elif mode == "Scoring Weights Configuration":
        render_weights_configuration()
    elif mode == "Scoring Guide":
        render_scoring_guide()

if __name__ == "__main__":
    main()