import streamlit as st
import base64

def render_professional_login():
    """Clean, professional login for financial services"""
    
    st.markdown("""
    <style>
    .header-section {
        background: #ffffff;
        padding: 25px 0;
        border-bottom: 1px solid #e9ecef;
        margin: -1rem -1rem 3rem -1rem;
        text-align: center;
    }
    .logo-title-section {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 8px;
    }
    .app-title {
        color: #343a40;
        font-size: 2rem;
        font-weight: 600;
        margin-left: 15px;
    }
    .app-subtitle {
        color: #6c757d;
        font-size: 1rem;
        margin: 0;
    }
    .login-container {
        max-width: 400px;
        margin: 40px auto;
        background: #ffffff;
        padding: 35px;
        border: 1px solid #dee2e6;
        border-radius: 6px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    }
    .login-title {
        color: #343a40;
        font-size: 1.4rem;
        font-weight: 600;
        text-align: center;
        margin-bottom: 25px;
    }
    .platform-features {
        background: #f8f9fa;
        padding: 40px 30px;
        margin: 50px -1rem -1rem -1rem;
    }
    .feature-row {
        background: white;
        padding: 20px;
        margin: 12px 0;
        border-left: 4px solid #007bff;
        border-radius: 4px;
    }
    .feature-title {
        color: #343a40;
        font-weight: 600;
        margin-bottom: 8px;
    }
    .feature-desc {
        color: #6c757d;
        font-size: 0.95rem;
        margin: 0;
    }
    .stButton > button {
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 12px 20px;
        font-weight: 500;
        width: 100%;
    }
    .stButton > button:hover {
        background-color: #0056b3;
    }
    .footer-section {
        text-align: center;
        padding: 20px;
        color: #6c757d;
        font-size: 0.9rem;
        border-top: 1px solid #e9ecef;
        margin: 40px -1rem -1rem -1rem;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Convert the Finequs logo to base64 (using the actual PNG from user)
    finequs_logo_b64 = "iVBORw0KGgoAAAANSUhEUgAAAIAAAABACAYAAADS1n9/AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAACTwAAAk8BjvKYcAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAp2SURBVHic7Z17jFzFFcZ/M2vv2mvvA4Md4wQCgQQTQpKSBGqFBAgJCEhBFAmKkFJVaqOqUlW1kZK2UtO0KVVF00RtpJZAQwikJKHQJhBCCYSQEAiPYPOOjW3Wfti739y5j9M/Zq53Z/bO7Ozcc2dmdz5pdOfeOXPOd853Z869c889M4KqkkQmoaqqrVYbx3GwbRvHcbBtu62PZVmodVUW6mhcvqbVFJWI53lks1lyuRy5XI5sNotlWcwrUwJVxbIs8vk8yWSSVCpFMpkkkUgQj8eJxWI10YdVQ/Rnp9PkNiTsNqGqWJZFqz+ZEQIo0ZHpJLlNaGckFyQIIoQhkWwKOwJGCOCfj0jQ4/dGCBAKiQTgO8ZvEcIgEqRhxHcQCdIwQt2bNUKAUBglgNAsIYQQQgghhBBCCCGEEEKI2EzXtGv0v7Aa/Xa8D/32/n1fHF9r7Dp7zWrVGGRp2npNaZROGdSo9poSQgghkMN3ooSt5TYhQe8PGYLs3Z4QoAkR6FdoJADddONqR4LWCRdh29iWdQJW/VjK6a+oHb3HyK+OFP8t6sO5jVrL96Uf6x5Hu8cRhgAfNsIoAhhhZd/BNGLVFrOp1gTKs7ov/PaAU+/TqI1G/TZqM2zttiNEfC+dYlzqj9vKtBQcjGaIZdvYlg2ujbNwAWpZWGNZbFsmhHvZvRhPWVbxt0KrPVdRrqZczQ3Ua9f/v96K7n07jZSn1vW5jV4T5jFaXvdGIqNW1pXjqufqgTbNGoJEKhGNRmtjX7fYqKrYlo1lO6S37CSxZjO9L7/IuJJMTJBL2hRMiRJWyJXSK/VPOLEsfFOu3wZXEaFUh/KeYkZF5WO1RV1fW6u9smOV6yivE/xDQOUnbttjN0OEBVC1Wz7Q3eDDOm7fKKCqoC1YzG3rNhJCZAsyabtABuWNt44xd/fXmLjhRcbFhKK6OMUfIVdV+5bOPsJo52S6t6I0E0hNP1X6qmZxzpbF/v3vM/9HP2LKjm1MshWqHKtR/+27zdrttm1bIrCKH9s4a5qgKFGgqla9FhJqJZQFHWRR+PYq5Xz0VFfDG+SqOo9zbzfIlh9jzGPP0//Yc6Sd4h8Hqqa6K/dLWNULUhBaJGNR0BK2I7CKTqF6bVrKIpCZGKJtUxbOCaJmtEMo+g+6gJtHBGgDy1LNGdkHMpnDSWZJJdOkcjmyeYF4xCa2+3kGfnoBE3duY8yuZcxJGiSaH0a1W0/V4vjjCXIVB5vAqtZkX1tGEUc9VJm8+xWl+YOu9VgzKuJfr2dFLZZh9QUCNXkY6nYRUNoXOUKJ0r6m3hqpCitKxiKeSCJIhawq+YKQSuVIphIkc3kKtkkkkiPWt4sxr77CxNdewO5fx5yJMaKfnsPYHQvI2Q6JKOjUxfQNf5+JO3azKC6YBIyx7kDK5tUykpVdRBhpqQjhilB5rTwOGwlAbKYKKCLEZqrQ9uuyLfIFIVMwSKdyJG0hZYlSlCwjJrEqFE3LDZFyHWJZCCfBzipjLDDfOMxJL7zCf2aOIbt3L4lhg3g8xonAcGBiwWD67n2Meuwp5k1IcMZjjzPv5s9hx2MYo8ag9tE2GhCmyJHyOLOg9lxdTyLOCREsWJiP32/DH5cNUvFHlHZEmLZNvqCkcxay+QK2VtSZAzLZ1n6XRFsJIOBaQiwDdkxIxhWKJmhMFdOGhAhJhYQIcRHSBbCqLCmTwBe8yI1XeR8BcEUx6l5TJa8KBxrxERF5Z9++fLa9kUEj3Z1G89eqUNa2eDZk7MJJWPu+hzV/MbZpktm9k/zObTg7tjCaAs8N9lM6bpM8cIi0JaRVSVtCqrS1VJW0QaIgJEWIqVKwNBAkuOGUBKdaQ3Qhj9eW4F8lfhJBKgkMN6kpgdqzVKrdOEGJJm3o+67JhQsP8a0vnc/E0b3s3p9iywWQ+c15xhMPnUNyfPXl3V/h/ZOQR3+4GrGLxO1dg9Jgzl38Zd9EoCb1fdtvJ/6v15ny+W/QN3MOu375a3J7duJIkQiWJaQNiKnWLKpFlQlVh6yKrI5DkCCTzjJnZi8nzEgy7YQkN/3wHTZuSfGVT06mb1ycl/6bY9eeFH8bm2eacajm9eAZzBpz87xz0g8tJUBbrvCdzkGI9YN3HsKyTfZ9++v07dtNdtce9t17F4ktb2ENH2HiMWL7kPZ/2KqQ2L+ZnkefoOfoEHff/Fk+e+4s3nl/gBvv2kp2KM/Sy4ZYfFo/b64/xqWnJVg4p3FWMGLXyJNGGJHgBB4NrPotqcqBZQuZdJ5N2w6R3f4O1oGdyGAbKlNaJBTXO/q/iFCIGuy9+kpWLruC8ycnef6Vw/zm/nfJJDKcP7+PT355HhPG9PB/t/vJUv5bfUUF6sGpINOqv/4hgoUdkGYz2qsAZhEhbIDEK0/Su+MNIgsWsfc7N+KNGF00Cjn4l9wSQHFtFctuPczjf7+A4UOKl3+7BHvB2UyePICfP/QXkqHdB6v8X7Db6I0QLATbOYGn3kUg+r1wDpDlqaXfJ5+3GXhzI7suvQpvxCiu/cHVzL7iu8QWLSqOhNV/A98QLBnAgZaAHZP5n5iJnPcJpu9YhT3nFMZMG0/f4P3kMx6JYolGkuG3+x8eBAhg3SDL97+3hKGDNLHe5xbQ//7XOLJnOyoGjz7yaK7s7WCE8+dO5uSTksT6JhKbfArDkm9iT5rKsa8uxx09jr97HyJ9/+9IJ1IkE8UdHVGtWO9qP2GpXnNqkfZ5zH4hQnvFRoKqKg8dBUcgjwJ6jkWrDYBfAmhQJfOWpGxRrCo3XQvZUZvmGZAC4x7FIFdRO8YiQNfN3z7UkGJqO3CfgHs7lnQ7mfEGFAdtTSK+WqOu0UStjfL+o/Ub/9ttvXlbL6V1WgqOhhFAKwggUjVHqOt7lWZNbWGI8N7ffsOG666nJ+2SjUQpmDGKnkOhYJFOJSikk6SXXY4zezb5fXvJHzlCv9vYzZBgaH8LJ+hsv1QO7t4bgOUHTVQW96vfaHBqOzaNBaAshPZjE36CJqvhBMZVvJzHTx98lHtvWYWTz5OIOHQP62Hzay8z/vDL5Gwhs3cfw3bsIHdwH5l0lqV33s5555zF8uXLWb16ddvGbQKYgL1m36j/jrCbpZYu0qxOwggBwrJCdKoISrV1NuzrnA0Ng3g6h+06nLz9LRaueQHLc7BWr2Hq9N1M7Mmx++hRBpJZjh47xsyPfbSNI24bFrCEOmg3EdqhOW3RZrAL+WvneDtSgMC1DuAqB5oMB5/6O7vPPIsJX72ehRs3MP2Fh8k5MTx3iGSPhwGkr/sqhz96EaeffbYJ7Y6KIdQhQVjFCLsIzeDfbdxIp1X/rJutKiTm8Heu3fgHr4h2D4Kqvnu4UztOJwRJwFYBn+qmYuKIzDSLBK1Y7VvVltCedHAtJHDHhKwdqrTZyoR8K/odQZ1oAHoqt8H3vR46bfK7Kq38j2cKGvxPdQhT7fxd/0fVFMHJoBsBMWTrhAAAAABJRU5ErkJggg=="
    
    # Header with logo
    st.markdown(f"""
    <div class="header-section">
        <div class="logo-title-section">
            <img src="data:image/png;base64,{finequs_logo_b64}" alt="Finequs" style="height: 35px;">
            <div class="app-title">LoanScoreAI v6.0</div>
        </div>
        <div class="app-subtitle">Professional Credit Risk Assessment Platform</div>
    </div>
    """, unsafe_allow_html=True)
    
    # Login section
    st.markdown("""
    <div class="login-container">
        <div class="login-title">System Access</div>
    """, unsafe_allow_html=True)
    
    with st.form("login_form"):
        username = st.text_input("Username", placeholder="Enter your username")
        password = st.text_input("Password", type="password", placeholder="Enter your password")
        
        submitted = st.form_submit_button("Sign In")
        
        if submitted:
            if username == "Finequs" and password == "Password321#":
                st.session_state.logged_in = True
                st.session_state.username = username
                st.success("Authentication successful")
                st.rerun()
            else:
                st.error("Invalid credentials")
    
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Platform capabilities
    st.markdown("""
    <div class="platform-features">
        <h3 style="color: #343a40; text-align: center; margin-bottom: 30px;">Platform Capabilities</h3>
        
        <div class="feature-row">
            <div class="feature-title">Risk Assessment Engine</div>
            <div class="feature-desc">20-variable scorecard with scientific calibration for accurate default probability assessment</div>
        </div>
        
        <div class="feature-row">
            <div class="feature-title">Bulk Processing</div>
            <div class="feature-desc">Handle up to 25,000 applications with comprehensive validation and Excel reporting</div>
        </div>
        
        <div class="feature-row">
            <div class="feature-title">Configurable Scoring</div>
            <div class="feature-desc">Adjustable scoring weights and thresholds to align with institutional risk requirements</div>
        </div>
        
        <div class="feature-row">
            <div class="feature-title">Audit & Compliance</div>
            <div class="feature-desc">Complete audit trails and compliance-ready documentation for regulatory oversight</div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Footer
    st.markdown("""
    <div class="footer-section">
        <strong>LoanScoreAI v6.0</strong> | Powered by <strong>Finequs</strong>
    </div>
    """, unsafe_allow_html=True)

    # Access information in sidebar
    with st.expander("Access Information"):
        st.info("""
        **Secure Access Portal**
        
        Contact your system administrator for login credentials.
        All access attempts are logged for security purposes.
        """)